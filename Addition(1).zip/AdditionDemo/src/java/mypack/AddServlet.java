package mypack;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AddServlet 
														extends HttpServlet {

	@Override
	protected void doGet(
HttpServletRequest request, 
HttpServletResponse response)
throws ServletException, IOException 
	{
				PrintWriter pw = 
												response.getWriter();
		
				response.setContentType("text/html");
				
				int x = Integer.parseInt(
										request.getParameter("txtFnum"));
				
				int y = Integer.parseInt(
										request.getParameter("txtSnum"));
				
				int ans = x + y;
				
				pw.print("<h1>Sum of "+x+" and "+y+
												" is "+ans+"</h1>");
	}

}
